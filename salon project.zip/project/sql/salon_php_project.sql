-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 31, 2022 at 09:13 AM
-- Server version: 8.0.28-0ubuntu0.20.04.3
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salon_php_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int UNSIGNED NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int NOT NULL,
  `service` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `aptNo` int NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `first_name`, `last_name`, `email`, `phone`, `service`, `date`, `time`, `aptNo`, `status`) VALUES
(1, 'mutua', 'james', 'er2@gmail.com', 43567890, 'Facial', '2022-03-24', '19:02:00', 658447463, ''),
(3, 'james', 'mutua\r\n', 'er3@gmail.com', 1234567890, 'hairdo', '2022-03-25', '19:05:00', 699495909, ''),
(4, 'james', '', 'er3@gmail.com', 1234567890, 'hairdo', '2022-03-25', '19:05:00', 299184418, '');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `name`, `email`, `message`) VALUES
(1, 'james', 'er2@gmail.com', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ex eligendi nisi sint ipsa ullam iste id iusto alias eos voluptatum.\r\n'),
(2, 'james', 'er2@gmail.com', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ex eligendi nisi sint ipsa ullam iste id iusto alias eos voluptatum.\r\n'),
(3, 'james', 'er3@gmail.com', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Harum ea autem rem sint, repudiandae blanditiis fuga, voluptate asperiores libero quos ipsa possimus, id eligendi! Nihil nobis corporis sint expedita reprehenderit.\r\n'),
(4, 'james', 'er3@gmail.com', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Harum ea autem rem sint, repudiandae blanditiis fuga, voluptate asperiores libero quos ipsa possimus, id eligendi! Nihil nobis corporis sint expedita reprehenderit.\r\n'),
(5, 'james', 'er3@gmail.com', 'qzwetxyrcftuvgbhkjlkm;l,;');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `phone` int NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`first_name`, `last_name`, `phone`, `email`, `pass`) VALUES
('james', 'james', 43567890, 'er2@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
('james', 'Mutua', 797460030, 'er3@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
('31ed', 'rew', 1234, 'cd2@dfsd.c', '6febad084de80fc7fdc694cbc9a060bf'),
('mn', 'f', 1234, 'er2@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
('james', 'james', 97460030, 'er3@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759'),
('Q', 'Q', 1, 'a', 'c20ad4d76fe97759aa27a0c99bff6710');

-- --------------------------------------------------------

--
-- Table structure for table `table_admin`
--

CREATE TABLE `table_admin` (
  `id` int UNSIGNED NOT NULL,
  `first_name` varchar(10) NOT NULL,
  `last_name` varchar(10) NOT NULL,
  `contact` int NOT NULL,
  `email` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `pass` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `table_admin`
--

INSERT INTO `table_admin` (`id`, `first_name`, `last_name`, `contact`, `email`, `pass`) VALUES
(1, 'james', 'mutua', 23456789, 'er3@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `table_page`
--

CREATE TABLE `table_page` (
  `id` int UNSIGNED NOT NULL,
  `page_type` varchar(200) NOT NULL,
  `page_title` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `page_description` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `location` varchar(255) NOT NULL,
  `contact` varchar(25) NOT NULL,
  `timing` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `table_page`
--

INSERT INTO `table_page` (`id`, `page_type`, `page_title`, `email`, `page_description`, `location`, `contact`, `timing`) VALUES
(1, 'contactus', 'Contact Us', 'elegance@gmail.com', 'We celebrate women and men in their real, most raw, authentic brilliance, who believe in themselves and are ready to step into the look they love. We employ hair products with some of the most natural and rich ingredients because we believe you should never expect less.', 'Nyeri Town', '+254742641439', '10:30 am to 7:30 pm');

-- --------------------------------------------------------

--
-- Table structure for table `table_pages`
--

CREATE TABLE `table_pages` (
  `id` int UNSIGNED NOT NULL,
  `page_type` varchar(100) NOT NULL,
  `page_title` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `page_description` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `contact` varchar(25) NOT NULL,
  `timing` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `table_pages`
--

INSERT INTO `table_pages` (`id`, `page_type`, `page_title`, `email`, `page_description`, `contact`, `timing`) VALUES
(1, 'aboutus', 'About Us', '', 'Our main focus is on quality and hygiene. Our Parlour is well equipped with advanced technology equipments and provides best quality services. Our staff is well trained and experienced, offering advanced services in Skin, Hair and Body Shaping that will provide you with a luxurious experience that leave you feeling relaxed and stress free. The specialities in the parlour are, apart from regular bleachings and Facials, many types of hairstyles, Bridal and cine make-up and different types of Facials & fashion hair colourings........', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `table_services`
--

CREATE TABLE `table_services` (
  `id` int UNSIGNED NOT NULL,
  `service` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `table_services`
--

INSERT INTO `table_services` (`id`, `service`, `price`) VALUES
(3, 'Facials', 500),
(4, 'fruit facial', 1500),
(5, 'Facials', 500),
(6, 'hairdo', 1500),
(7, 'Urembo tu', 5400),
(8, 'new', 900),
(10, 'Facials', 5000),
(11, 'Facial', 5000),
(12, 'bet', 432),
(13, 'bett', 4325),
(14, 'foottttt', 550),
(15, 'Somethingg', 1500),
(16, 'mpyaaa', 900);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_admin`
--
ALTER TABLE `table_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_page`
--
ALTER TABLE `table_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_pages`
--
ALTER TABLE `table_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_services`
--
ALTER TABLE `table_services`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `table_admin`
--
ALTER TABLE `table_admin`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `table_page`
--
ALTER TABLE `table_page`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `table_pages`
--
ALTER TABLE `table_pages`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `table_services`
--
ALTER TABLE `table_services`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
