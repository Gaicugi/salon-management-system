<?php
include('./Partials/dbconnection.php');

if (isset($_POST['submit'])) {

   $name = $_POST['name'];
   $email = $_POST['email'];
   $message = $_POST['message'];

   $query = mysqli_query($con, "insert into questions (name, email, message) values('$name','$email','$message')");
   $err = mysqli_error($con);
   if ($query) {
      echo "<script>window.alert('Success');</script>";
      echo "<script>window.location.href = './contact_us.php';</script>";
   } else {
      $msg = "Something Went Wrong. Please try again";
      echo $msg . $err;
      // echo "<script>window.alert('Failed')</script>";
   }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/contact.css">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   <title>Document</title>
</head>

<body>
   <?php include_once('./Partials/NavBar.php') ?>
   <section class="section-bg" style="background-image: url(https://images.unsplash.com/photo-1470259078422-826894b933aa?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8c2Fsb24lMjBpbWFnZXN8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60);" data-scroll-index="7">
      <div class="overlay pt-100 pb-100 ">
         <div class="container">
            <div class="row">
               <div class="col-lg-6 d-flex align-items-center">
                  <div class="contact-info">

                     <h2 class="contact-title">Have Any Questions?</h2>
                     <?php
                     $ret = mysqli_query($con, "SELECT * FROM table_page");
                     $cnt = 1;

                     while ($row = mysqli_fetch_array($ret)) {

                     ?>
                        <p><?php echo $row['page_description']; ?></p>
                        <ul class="contact-info">
                           <li>
                              <div class="info-left">
                                 <i class="fas fa-mobile-alt"></i>
                              </div>
                              <div class="info-right">
                                 <h4><?php echo $row['contact']; ?></h4>
                              </div>
                           </li>
                           <li>
                              <div class="info-left">
                                 <i class="fas fa-at"></i>
                              </div>
                              <div class="info-right">
                                 <h4><?php echo $row['email']; ?></h4>
                              </div>
                           </li>
                           <li>
                              <div class="info-left">
                                 <i class="fas fa-map-marker-alt"></i>
                              </div>
                              <div class="info-right">
                                 <h4><?php echo $row['location']; ?></h4>
                              </div>
                           </li>
                        </ul>
                     <?php } ?>
                  </div>
               </div>
               <div class="col-lg-6 d-flex align-items-center">
                  <div class="contact-form">
                     <!--Contact Form-->
                     <form action="./contact_us.php" id='contact-form' method='POST'><input type='hidden' name='form-name' value='contactForm' />
                        <p style="font-size:16px; color:red" align-items="center"> <?php if ($msg) {
                                                                                       echo $msg;
                                                                                    }  ?> </p>

                        <div class="row">
                           <div class="col-md-12">
                              <div class="form-group">
                                 <input type="text" name="name" class="form-control" id="first-name" placeholder="Enter Your Name *" required="required">
                              </div>
                           </div>
                           <div class="col-md-12">
                              <div class="form-group">
                                 <input type="email" name="email" class="form-control" id="email" placeholder="Enter Your Email *" required="required">
                              </div>
                           </div>

                           <div class="col-md-12">
                              <div class="form-group">
                                 <textarea rows="4" name="message" class="form-control" id="description" placeholder="Enter Your Message *" required="required"></textarea>
                              </div>
                           </div>
                           <div style="padding-top: 15px;" class="col-md-12">
                              <!--contact button-->
                              <button type="submit" name="submit" class="btn btn-primary">
                                 Send Us <i class="fas fa-arrow-right"></i>
                              </button>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <?php include_once('./Partials/Footer.php') ?>
</body>

</html>