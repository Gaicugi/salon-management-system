<?php
   include('./Partials/dbconnection.php');

   if (isset($_POST['submit'])) {

		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$service = $_POST['services'];
		$date = $_POST['date'];
		$time = $_POST['time'];
		$aptnumber = mt_rand(100000000, 999999999);

		$query = mysqli_query($con, "insert into appointments (first_name, last_name, email, phone, service, date, time, aptNo) value('$first_name','$last_name','$email','$phone','$service','$date','$time','$aptnumber')");
		$err = mysqli_error($con);
      if ($query) {

			echo "<script>window.alert('Success');</script>";
		} else {
			// $msg = "Something Went Wrong. Please try again";
			echo "<script>window.alert('Failed')</script>";


		}
	}
?>





<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>ELEGANCE</title>
   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="./css/index.css">
   <link rel="stylesheet" href="./css/footer.css">
   <!-- CSS only -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
   <?php include_once('./Partials/NavBar.php') ?>
   <div class="main">

      <body>
         <ul class="nav justify-content-center">
            <li class="nav-item">
               <a class="nav-link active" href="./index.html">Home</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="./login.html">LogIn</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="./navbar.html">Navbar</a>
            </li>
         </ul>




         <div id="carouselId" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
               <li data-target="#carouselId" data-slide-to="0" class="active"></li>
               <li data-target="#carouselId" data-slide-to="1"></li>
               <li data-target="#carouselId" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
               <div class="carousel-item active">
                  <img class="carousel-image" src="https://www.hji.co.uk/wp-content/efs/2019/09/Anne-Afro-19-2-17_10175.jpg" alt="Second slide">

                  <div class="carousel-caption d-none d-md-block">
                     <h3>Be Pretty</h3>
                     <p>Embrace the diversity</p>

                  </div>
               </div>
               <div class="carousel-item">
                  <img class="carousel-image" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFQd-VuwzqeKyWDPenkruXkjfQO4cengd2bw&usqp=CAU" alt="First slide">
                  <div class="carousel-caption d-none d-md-block">


                     <h3> save money! save time!</h3>

                  </div>
               </div>
               <div class="carousel-item">
                  <img class="carousel-image" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOMDtVA-9G4wJprqNTqfHr3BYm0cr64CYPAw&usqp=CAU" alt="Third slide">
                  <div class="carousel-caption d-none d-md-block">
                     <h3>Look Pretty</h3>
                     <p>Be confident</p>
                  </div>
               </div>
            </div>
            <a class="carousel-control-prev" href="#carouselId" role="button" data-slide="prev">
               <span class="carousel-control-prev-icon" aria-hidden="true"></span>
               <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselId" role="button" data-slide="next">
               <span class="carousel-control-next-icon" aria-hidden="true"></span>
               <span class="sr-only">Next</span>
            </a>
         </div>

         <div class="bmi">
            <div id="container">
               <!--This is a division tag for body container-->
               <div id="body_header">
                  <!--This is a division tag for body header-->
                  <h1>Appointment Request Form</h1>
                  <p>Make your appointments more easier</p>

               </div>
               <form action="index.php" method="post">

                  <fieldset>
                     <label>First Name:</label>
                     <input type="text" name="first_name" required>
                     <label>Last Name:</label>
                     <input type="text" name="last_name" required>
                     <label>Email:</label>
                     <input type="email" name="email">
                     <label>Phone:</label>
                     <input type="text" name="phone" required>
                     <label for="service">Service:</label>
                     <select id="services" name="services" required>
                        <option value="">Select Services</option>
                        <?php
                           $query = mysqli_query($con, "select * from table_services");
                           while ($row = mysqli_fetch_array($query)) {

                        ?>
                           <option value="<?php echo $row['service']; ?>"><?php echo $row['service']; ?></option>
                        <?php } ?>
                     </select>                     
                     <label for="date">Date*:</label>
                     <input type="date" name="date" value="" required></input>
                     <br>
                     <label for="time">Time*:</label>
                     <input type="time" name="time" value="" required></input>
                     <br>

                  </fieldset>
                  <button name="submit" type="submit">Request For Appointment</button>
               </form>
            </div>
         </div>

   </div>
   <?php include_once('./Partials/Footer.php') ?>
</body>

</html>