<?php
include('./Partials/dbconnection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Services</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="./css/style.css">
</head>

<body style="height: 100%;">

	<?php include_once('./Partials/NavBar.php') ?>
	<div class="service">
		<h1>Our Services</h1>
		<table class="table">
			<thead>
				<th>#</th>
				<th>Service Name</th>
				<th>Price</th>
			</thead>
			<tbody>
				<?php
				$ret = mysqli_query($con, "SELECT * FROM table_services");
				$cnt = 1;

				while ($row = mysqli_fetch_array($ret)) {

				?>
					<tr>
						<td><?php echo $cnt; ?></td>
						<td><?php echo $row['service']; ?></td>
						<td><?php echo $row['price']; ?></td>
					</tr>
				<?php
					$cnt += 1;
				}
				?>
			</tbody>
		</table>
	</div>
	</div>
</body>

<?php include_once('./Partials/Footer.php') ?>

</html>