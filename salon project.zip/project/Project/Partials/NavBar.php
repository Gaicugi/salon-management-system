<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/NavBar.css">
	<link rel="stylesheet" href="../css/footer.css">
	<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>

	<title>Elegance Salon</title>
</head>

<body>
	<nav>
		<div class="nav-bar">
			<i class='bx bx-menu sidebarOpen'></i>
			<span class="logo navLogo"><a href="#">Elegance Salon</a></span>

			<div class="menu">
				<div class="logo-toggle">
					<span class="logo"><a href="#">Elegence Salon</a></span>
					<i class='bx bx-x siderbarClose'></i>
				</div>

				<ul class="nav-links">
					<li><a href="../index.php">Home</a></li>
					<li><a href="../about_us.php">About</a></li>
					<li><a href="../services.php">Services</a></li>
					<li><a href="../contact_us.php">Contact Us</a></li>
					<li><a href="../logout.php">Log Out</a></li>
				</ul>
			</div>

			<!-- <div class="darkLight-searchBox">
				<div class="dark-light">
					<i class='bx bx-moon moon'></i>
					<i class='bx bx-sun sun'></i>
				</div>

				<div class="searchBox">
					<div class="searchToggle">
						<i class='bx bx-x cancel'></i>
						<i class='bx bx-search search'></i>
					</div>

					<div class="search-field">
						<input type="text" placeholder="Search...">
						<i class='bx bx-search'></i>
					</div> -->
				<!-- </div>
			</div> -->
		</div>
	</nav>
	<script>
		const body = document.querySelector("body"),
			nav = document.querySelector("nav"),
			modeToggle = document.querySelector(".dark-light"),
			searchToggle = document.querySelector(".searchToggle"),
			sidebarOpen = document.querySelector(".sidebarOpen"),
			siderbarClose = document.querySelector(".siderbarClose");	

		//   js code to toggle sidebar
		sidebarOpen.addEventListener("click", () => {
			nav.classList.add("active");
		});

		body.addEventListener("click", e => {
			let clickedElm = e.target;

			if (!clickedElm.classList.contains("sidebarOpen") && !clickedElm.classList.contains("menu")) {
				nav.classList.remove("active");
			}
		});
	</script>









	<!-- <!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" href="./css/NavBar.css" />
	<link rel="stylesheet" href="./css/footer.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
	<title>Elegance</title>
</head>

<body>
	<div class="all">
		<div class="content">
			<nav class="navbar">
				<div class="logo">ELEGANCE SALON</div>
				<ul class="nav-links">
					<input type="checkbox" id="checkbox_toggle" />
					<label for="checkbox_toggle" class="checkboxbtn">&#9776;</label>
					<div class="menu">
						<li><a href="/">Home</a></li>
						<li><a href="/about_us.php">About</a></li>
						<li><a href="./services.php">Services</a></li>
						<li class="services">
							<a href="/">Services</a>
							<ul class="dropdown">
								<li><a href="/">Hair Dressing</a></li>
								<li><a href="/">Manicure</a></li>
								<li><a href="/">Pedicure</a></li>
								<li><a href="/">Hair Cutting</a></li>
								<li><a href="/">Skin Care Treatments</a></li>
								<li><a href="/">Waxing</a></li>
								<li><a href="/">Tanning</a></li>
							</ul>
						</li> -->
	<!-- <li><a href="/">Pricing</a></li> -->
	<!-- <li><a href="/contact_us.php">Contact</a></li>
	<li><a href="/">Log Out</a></li>
	</div>
	</ul>
	</nav>
	</div>
	</div> --> 