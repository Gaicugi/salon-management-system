<?php
   $con = mysqli_connect("localhost", "jamess", "New\$Things1", "salon_php_project");
   if(mysqli_connect_errno()){
   	echo "Connection Fail". mysqli_connect_error();
   }

?>
