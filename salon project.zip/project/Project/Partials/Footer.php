<div class="footer">
   <footer>
      <div class="content">
         <div class="left box">
            <div class="upper">
               <div class="topic">About us</div>
               <p>Elegance</p>
            </div>
            <div class="lower">
               <div class="topic">Contact us</div>
               <div class="phone">
                  <a href="#"><i class="fas fa-phone-volume"></i>+254 97460030</a>
               </div>
               <div class="email">
                  <a href="#"><i class="fas fa-envelope"></i>elegance@gmail.com</a>
               </div>
            </div>
         </div>
         <div class="middle box">
            <div class="topic">Links</div>
            <div><a href="../index.php">Home</a></div>
            <div><a href="../contact_us.php">Contact us</a></div>
            <div><a href="../services.php">Services</a></div>
            <div><a href="../about_us.php">About Us</a></div>
            <div><a href="../admin/login.php">Admin</a></div>
            <div><a href="#"></a></div>
         </div>
         <div class="right box">
            <div class="topic">Follow us</div>
            <div class="media-icons">
               <a href="#"><i class="fab fa-facebook-f"></i></a>
               <a href="#"><i class="fab fa-instagram"></i></a>
               <a href="#"><i class="fab fa-twitter"></i></a>
               <a href="#"><i class="fab fa-youtube"></i></a>
               <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
         </div>
      </div>
      <div class="bottom">
         <p>Copyright © 2022 <a href="#">Elegance</a> All rights reserved</p>
      </div>
   </footer>
</div>


</body>

</html>