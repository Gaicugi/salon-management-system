<?php
   include('./Partials/dbconnection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/view-appointment.css">
   <title>Document</title>
</head>

<body>
   <?php include_once('./Partials/sidebar.php'); ?>
   <div class="main" style="margin-top: 40px;">
      <?php
      $vid = $_GET['viewid']; ?>
      <h3 style="font-weight: bold;">Customer <?php echo $vid?></h3>
      <div class="table">
         <table width="100%">
            <?php
            $vid = $_GET['viewid'];
            $ret = mysqli_query($con, "SELECT * FROM registration WHERE id = '$vid'");
            $cnt = 1;

            while ($row = mysqli_fetch_array($ret)) {

            ?>
               <tr>
                  <th>First Name </th>
                  <td><?php echo $row['first_name']; ?></td>
               </tr>
               <tr>
                  <th>Last Name</th>
                  <td><?php echo $row['last_name']; ?></td>
               </tr>
               <tr>
                  <th>Email</th>
                  <td><?php echo $row['email']; ?></td>
               </tr>
               <tr>
                  <th>Phone</th>
                  <td><?php echo $row['phone']; ?></td>
               </tr>
            <?php $cnt = $cnt + 1;
            } ?>
            <!-- </tbody> -->
         </table>
      </div>
      <div style="padding: 20px;" class="buttons">
         <button style="padding: 15px; background-color: green;" type="button" onclick="window.location.href = './customers.php'">Go back</button>
      </div>
   </div>
</body>

</html>