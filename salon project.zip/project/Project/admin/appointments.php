<?php
include('./Partials/dbconnection.php');


if (isset($_POST['submit'])) {
   $service_name = $_POST['service_name'];
   $price = $_POST['price'];

   $query = mysqli_query($con, "insert into  table_services(service, price) values('$service_name','$price')");
   if ($query) {
      echo "<script>alert('Service has been added.');</script>";
      echo "<script>window.location.href = 'services.php'</script>";
      $msg = "";
   } else {
      echo "<script>alert('Something Went Wrong. Please try again.');</script>";
   }
}
// }

?>



<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/services.css">
   <!-- CSS only -->
   <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->
   <title>Document</title>
</head>

<body>

   <?php include_once('./Partials/sidebar.php'); ?>
   <div class="main" style="margin-top: 40px;">
      <h3 style="color: red;">All Appointments</h3>
      <table width="100%">
         <thead>
            <tr>
               <th>#</th>
               <th>First Name</th>
               <th>Last Name</th>
               <th>Email</th>
               <th>Phone</th>
               <th>Service</th>
               <th>Date</th>
               <th>Time</th>
               <th>Appointment Number</th>
               <th>Action</th>
            </tr>
         </thead>
         <tbody>
            <?php
            $ret = mysqli_query($con, "SELECT * FROM appointments");
            $cnt = 1;

            while ($row = mysqli_fetch_array($ret)) {

            ?>
               <tr>
                  <td><?php echo $cnt; ?></td>
                  <td><?php echo $row['first_name']; ?></td>
                  <td><?php echo $row['last_name']; ?></td>
                  <td><?php echo $row['email']; ?></td>
                  <td><?php echo $row['phone']; ?></td>
                  <td><?php echo $row['service']; ?></td>
                  <td><?php echo $row['date']; ?></td>
                  <td><?php echo $row['time']; ?></td>
                  <td><?php echo $row['aptNo']; ?></td>
                  <td><a style="color: blue; text-decoration: none;" href="view-appointment.php?viewid=<?php echo $row['id']; ?>">View</a></td>
               </tr>
            <?php $cnt = $cnt + 1;
            } ?>
         </tbody>


      </table>
   </div>



</body>
<script>
   const modal = document.getElementById('id01');
   window.onclick = function(event) {
      if (event.target == modal) {
         modal.style.display = "none";
      }
   }
</script>

</html>