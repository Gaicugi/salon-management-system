<?php
include('./Partials/dbconnection.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/view-appointment.css">
   <title>Document</title>
</head>

<body>
   <?php include_once('./Partials/sidebar.php'); ?>
   <div class="main" style="margin-top: 40px;">
      <h3 style="font-weight: bold;">Message</h3>
      <div class="table">
         <table width="100%">
            <!-- <tbody> -->
            <?php
            $vid = $_GET['viewid'];
            $ret = mysqli_query($con, "SELECT * FROM questions WHERE id = '$vid'");
            $cnt = 1;

            while ($row = mysqli_fetch_array($ret)) {

            ?>
               <tr>
                  <th style="min-width: 100px;">Name</th>
                  <td><?php echo $row['name']; ?></td>
               </tr>
               <tr>
                  <th style="min-width: 100px;">Email</th>
                  <td><?php echo $row['email']; ?></td>
               </tr>
               <tr>
                  <th style="min-width: 100px;">Message</th>
                  <td><?php echo $row['message']; ?></td>
               </tr>
               
            <?php $cnt = $cnt + 1;
            } ?>
            <!-- </tbody> -->
         </table>
      </div>
      <div style="padding: 20px;" class="buttons">
         <button  style="padding: 15px; background-color: green;" type="button" onclick="window.location.href = './messages.php'">Go back</button>
      </div>
   </div>
</body>

</html>