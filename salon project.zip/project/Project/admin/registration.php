<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Register Elegant</title>
    <link rel="stylesheet" href="./css/auth.css" />
</head>

<body>
    <?php
    include('./Partials/dbconnection.php');
    // When form submitted, insert values into the database.
    if (isset($_POST['submit'])) {
        // removes backslashes
        $First_name = stripslashes($_POST['First_name']);
        //escapes special characters in a string
        $First_name = mysqli_real_escape_string($con, $_POST['First_name']);
        $Last_name = stripslashes($_POST['Last_name']);
        $Last_name = mysqli_real_escape_string($con, $_POST['Last_name']);
        $email = stripslashes($_POST['email']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $Pass_word = $_POST['Pass_word'];
        $Pass_word = stripslashes($_POST['Pass_word']);
        $Pass_word = mysqli_real_escape_string($con, $_POST['Pass_word']);
        $hashedPass = md5($Pass_word);
        $phone = stripslashes($_POST['phone']);
        $phone = mysqli_real_escape_string($con, $_POST['phone']);


        $query = "INSERT into table_admin(first_name, last_name, phone, email, pass) VALUES ('$First_name','$Last_name','$phone', '$email','$hashedPass')";
        // die($query);
        $result = mysqli_query($con, $query);
        if ($result) {
            echo "<script>alert('User has been added.');</script>";
            echo "<script>window.location.href = './dashboard.php'</script>";
           
        } else {
            echo "<script>alert('Failed');</script>";
          
        }
    }
    ?>
        <form class="form" action="./registration.php" method="POST">
            <h1 class="login-title">Registration</h1>
            <input type="text" class="login-input" name="First_name" placeholder="First Name" required>
            <input type="text" class="login-input" name="Last_name" placeholder="Last Name">
            <input type="text" class="login-input" name="phone" placeholder="Phone number" required />
            <input type="text" class="login-input" name="email" placeholder="Email Adress">
            <input type="password" class="login-input" name="Pass_word" placeholder="Password" required>
            <input type="submit" name="submit" value="Register" class="login-button">
            <p class="link">Already have an account.<a href="login.php"
            style="color: blue; font-weight: bold; text-decoration: none;"
            > Login</a></p>
            <p class="link"><a href="reset-password.php">Reset Password</a></p>
        </form>
    
<script>
    const pass = (form) => {
        pass = form.pass_word.value;
        pass1 = form.pass_word1.value;

        if (pass != pass1) {
            document.getElementById('new').innerHTML = 'Passwords don`t match';
        }
    }
</script>

</body>

</html>