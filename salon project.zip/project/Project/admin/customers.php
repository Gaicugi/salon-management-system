<?php
include('./Partials/dbconnection.php');


if (isset($_POST['submit'])) {
   $first_name = $_POST['first_name'];
   $last_name = $_POST['last_name'];
   $phone = $_POST['phone'];
   $email = $_POST['email'];

   $query = mysqli_query($con, "insert into registration(first_name, last_name, phone, email) values('$first_name','$last_name', '$phone', '$email')");
   if ($query) {
      echo "<script>alert('Service has been added.');</script>";
      echo "<script>window.location.href = 'services.php'</script>";
      $msg = "";
   } else {
      echo "<script>alert('Something Went Wrong. Please try again.');</script>";
   }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/services.css">
   <!-- CSS only -->
   <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->
   <title>Document</title>
</head>

<body>

   <?php include_once('./Partials/sidebar.php'); ?>
   <div class="main" style="margin-top: 30;">
      <!-- <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Add Customer</button> -->

      <!-- <div id="id01" class="modal">

         <form class="modal-content animate" method="POST" action="./services.php">
            <div class="imgcontainer">
               <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
            </div>

            <div class="container">
               <h3>Add Customer</h3>
               <label>First Name</label>
               <input type="text" name="first_name" required>
               <label>Last Name</label>
               <input type="text" name="last_name" required>
               <label>Phone</label>
               <input type="text" name="phone" required>
               <label>Email</label>
               <input type="email" name="email" required>

               <button type="submit" name="submit">Add</button>
            </div>

            <div class="container" style="background-color:#f1f1f1">
               <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
            </div>
         </form>
      </div> -->
      <h3>Customers</h3>


      <table width="100%">
         <thead>
            <tr>
               <th>#</th>
               <th>First Name</th>
               <th>Last Name</th>
               <th>Phone</th>
               <th>Email</th>
               <!-- <th>Action</th> -->
            </tr>
         </thead>
         <tbody>
            <?php
            $ret = mysqli_query($con, "SELECT * FROM registration");
            $cnt = 1;

            while ($row = mysqli_fetch_array($ret)) {

            ?>
               <tr>
                  <td><?php echo $cnt; ?></td>
                  <td><?php echo $row['first_name']; ?></td>
                  <td><?php echo $row['last_name']; ?></td>
                  <td><?php echo $row['phone']; ?></td>
                  <td><?php echo $row['email']; ?></td>
                  <!-- <td><a style="color: blue; text-decoration: none;" href="view-customer.php?editid=<?php echo $row['id']; ?>">View</a>|| </span><a style="color: red; text-decoration: none;" href="delete_services.php?editid=<?php ///echo $row['id']; ?>">Delete</a></td> -->
               </tr>
            <?php $cnt = $cnt + 1;
            } ?>
         </tbody>


      </table>
   </div>



</body>
<script>
   const modal = document.getElementById('id01');
   window.onclick = function(event) {
      if (event.target == modal) {
         modal.style.display = "none";
      }
   }
   
</script>

</html>