<?php 
   session_start();
   include('./Partials/dbconnection.php');
   if (isset($_POST['submit'])) {
      $service_name = $_POST['service_name'];
      $price = $_POST['price'];
      $eid = $_GET['editid'];

      $query = mysqli_query($con, "DELETE FROM table_services WHERE id = '$eid'");
      if ($query) {
         // $msg = "Service has been deleted.";
         echo "<script>alert('Service deleted Successfully');</script>";
         echo "<script>window.location.href = 'services.php'</script>";
         $msg = "";
		} else {
			$msg = "Something Went Wrong. Please try again";
		}
   }
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/edit_services.css">
   <title>Document</title>
</head>

<body>
   <?php include_once('./Partials/sidebar.php') ?>
   <div class="login-page">
      <div class="form">
         <form class="login-form" method="POST">  
				<p style="font-size:16px; color:red" align-items="center"> <?php if ($msg) { echo $msg;}  ?> </p>
            <?php
               $cid = $_GET['editid'];
               
               $ret = mysqli_query($con, "select * from  table_services where id ='$cid'");
               $cnt = 1;
               while ($row = mysqli_fetch_array($ret)) {

            ?>
               <h3>Delete Service</h3>
               <label for="service">Service name</label>
               <input type="text" name="service_name" value="<?php echo $row['service']; ?>" />
               <label for="price">Price</label>
               <input type="text" name="price" value="<?php echo $row['price']; ?>"  />
               <?php } ?>
               <button name="submit" onclick="window.location.href = './services.php'" style="background-color: red;" type="submit">Delete</button> <br> <br>
               <button style="background-color: green;" type="button" onclick="window.location.href = './services.php'">Go back</button>
         </form>
      </div>
   </div>
</body>

</html>