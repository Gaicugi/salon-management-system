<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Login</title>
    <link rel="stylesheet" href="./css/auth.css" />
</head>

<body>
    <?php
    // require('db.php');
    include('./Partials/dbconnection.php');
    session_start();
    // When form submitted, check and create user session.
    if (isset($_POST['submit'])) {
        $email = $_POST['email'];    // removes backslashes
        // $email = mysqli_real_escape_string($con, $email);
        $Pass_word = $_POST['Pass_word'];
        // $Pass_word = mysqli_real_escape_string($con, $Pass_word);
        // $hashedpass = md5($Pass_word);
        // Check user is exist in the database
        $query = "SELECT * FROM table_admin WHERE email='$email' AND pass='$Pass_word'";
        $result = mysqli_query($con, $query) or die(mysqli_connect_error() . "Shit");
        $rows = mysqli_num_rows($result);
        if ($rows == 1) {
            $res = mysqli_fetch_row($result);
            // $_SESSION['firstname'] = $res['First_name'];
            // Redirect to user dashboard page
            echo "<script>window.location.href = './dashboard.php'</script>";
                        
            //header("Location:services.php");
        } else {
            include_once('./admin/login.php');
            $msg = "Invalid login credentials. PLease try again.";
        }
    }// else {
    ?>
        <form class="form" action="./login.php" method="POST" name="login">
            <h1 class="login-title">Login</h1>
			<p style="font-size:16px; color:red" align-items="center"> <?php if ($msg) { echo $msg;}  ?> </p>

            <input type="email" class="login-input" name="email" placeholder="Email" autofocus="true" />
            <input type="password" class="login-input" name="Pass_word" placeholder="Password" />
            <input type="submit" value="Login" name="submit" class="login-button" />
            <!-- <p class="link"><a href="registration.php">Register </a></p> -->
            <p class="link"><a href="./reset-password.php" style="text-decoration: none; color: blue;">Forgot Password</a></p>
        </form>
    <!-- <?php
    
    ?> -->
</body>

</html>