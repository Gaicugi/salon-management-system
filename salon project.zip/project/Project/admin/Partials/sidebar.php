<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
   <meta charset="UTF-8">
   <link rel="stylesheet" href="./css/sidebar.css">
   <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
</head>

<body>
   <div class="sidebar">
      <div class="logo-details">
         <div class="logo_name">Salon</div>
         <i class='bx bx-menu' id="btn"></i>
      </div>
      <ul class="nav-list">
         <li>
            <a href="./dashboard.php">
               <i class='bx bx-grid-alt'></i>
               <span class="links_name">Dashboard</span>
            </a>
            <span class="tooltip">Dashboard</span>
         </li>
         <li>
            <a href="./aboutus.php">
               <i class='bx bx-book'></i>
               <span class="links_name">About Us</span>
            </a>
            <span class="tooltip">About Us</span>
         </li>
         <li>
            <a href="./contactus.php">
               <i class='bx bx-phone'></i>
               <span class="links_name">Contact Us</span>
            </a>
            <span class="tooltip">Contact Us</span>
         </li>
         <li>
            <a href="./services.php">
               <i class='bx bx-chevron-right'></i>
               <span class="links_name">Services</span>
            </a>
            <span class="tooltip">Services</span>
         </li>
         <li>
            <a href="./customers.php">
               <i class='bx bx-user'></i>
               <span class="links_name">Customers</span>
            </a>
            <span class="tooltip">Customers</span>
         </li>
         <li>
            <a href="./messages.php">
               <i class='bx bx-chat'></i>
               <span class="links_name">Messages</span>
            </a>
            <span class="tooltip">Messages</span>
         </li>
         <!-- <li>
            <a href="#">
               <i class='bx bx-user-plus'></i>
               <span class="links_name">Add Customer</span>
            </a>
            <span class="tooltip">Add Customer</span>
         </li> -->
         <li>
            <a href="./appointments.php">
               <i class='bx bx-list-ol'></i>
               <span class="links_name">Appointments</span>
            </a>
            <span class="tooltip">Appointments</span>
         </li>
         
         <li>
            <a href="./profile.php">
               <i class='bx bx-cog'></i>
               <span class="links_name">Settings</span>
            </a>
            <span class="tooltip">Settings</span>
         </li>
         <li>
            <a href="./logout.php">
               <i class='bx bx-log-out'></i>
               <span class="links_name">Log Out</span>
            </a>
            <span class="tooltip">Log Out</span>
         </li>
      </ul>
   </div>
   <script>
      let sidebar = document.querySelector(".sidebar");
      let closeBtn = document.querySelector("#btn");
      let searchBtn = document.querySelector(".bx-search");

      closeBtn.addEventListener("click", () => {
         sidebar.classList.toggle("open");
         menuBtnChange(); //calling the function(optional)
      });

      searchBtn.addEventListener("click", () => { // Sidebar open when you click on the search iocn
         sidebar.classList.toggle("open");
         menuBtnChange(); //calling the function(optional)
      });

      // following are the code to change sidebar button(optional)
      function menuBtnChange() {
         if (sidebar.classList.contains("open")) {
            closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); //replacing the iocns class
         } else {
            closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); //replacing the iocns class
         }
      }
   </script>
</body>

</html>