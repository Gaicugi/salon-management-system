<?php
include('./Partials/dbconnection.php');

if (isset($_POST['submit'])) {
   $page_title = $_POST['page_title'];
   $pagedesc = $_POST['pagedesc'];

   $query = mysqli_query($con, "update table_pages set page_title = '$page_title', page_description = '$pagedesc' where page_type = 'aboutus'");
   if ($query) {
      $msg = "Updated Successfully";
      // echo "<script>window.location.href = 'services.php'</script>";

   } else {
      $msg = "Something Went Wrong. Please try again.";
   }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/edit_services.css">
   <title>Document</title>
</head>

<body>
   <?php include_once('./Partials/sidebar.php') ?>
   <div class="login-page">
      <div class="form">
         <form class="login-form" method="POST">
				<p style="font-size:16px; color:red" align-items="center"> <?php if ($msg) { echo $msg;}  ?> </p>
            <?php
               
               $ret = mysqli_query($con, "select * from  table_pages where page_type='aboutus'");
               $cnt = 1;
               while ($row = mysqli_fetch_array($ret)) {

            ?>
               <h3>Edit Page Details</h3>
               <label for="service">Page</label>
               <input type="text" name="page_title" value="<?php echo $row['page_title']; ?>" />
               <label for="price">Description.</label>
               <textarea style="height: 280px; width: 270px;" id="pagedesc" name="pagedesc"><?php echo $row['page_description'];?></textarea>
               <?php } ?>
               <button name="submit" type="submit">Update</button> <br> <br>
               <button style="background-color: green;" type="button" onclick="window.location.href = './dashboard.php'">Go back</button>
         </form>
      </div>
   </div>
</body>

</html