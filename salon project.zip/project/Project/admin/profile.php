<?php 
   session_start();
   include('./Partials/dbconnection.php');
   if (isset($_POST['submit'])) { 
      $fname = $_POST['first_name'];
      $lname = $_POST['last_name'];
		$contact = $_POST['contact'];
      $email = $_POST['email'];

		$query = mysqli_query($con, "update table_admin set first_name ='$fname', last_name ='$lname', contact='$contact', email='$email' where ID='1'");
		if ($query) {
			$msg = "Admin profile has been updated.";
		} else {
			$msg = "Something Went Wrong. Please try again.";
		}
   }
?>


<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/edit_services.css">
   <title>Document</title>
</head>

<body>
   <?php include_once('./Partials/sidebar.php') ?>
   <div class="login-page">
      <div class="form">
         <form class="login-form" method="POST">
               <h3>Edit Profile Details</h3>
               <p style="font-size:16px; color:red; align-items=center;" > <?php if ($msg) { echo $msg; }  ?> </p>

									<?php
									$ret = mysqli_query($con, "select * from table_admin where id='1'");
									$cnt = 1;
									while ($row = mysqli_fetch_array($ret)) {

									?>
               <label for="fname">First Name</label>
               <input type="text" name="first_name" value="<?php echo $row['first_name']; ?>" />
               <label for="lname">Last name</label>
               <input type="text" name="last_name" value="<?php echo $row['last_name']; ?>"  />
               <label for="contact">Contact</label>
               <input type="text" name="contact" value="<?php echo $row['contact']; ?>"  />
               <label for="email">Email</label>
               <input type="email" name="email" value="<?php echo $row['email']; ?>"  />
               <?php $cnt+=1; }?>
               <button name="submit" type="submit">Update</button> <br> <br>
               <button style="background-color: green;" type="button" onclick="window.location.href = './admin.php'">Go back</button>
         </form>
      </div>
   </div>
</body>

</html>