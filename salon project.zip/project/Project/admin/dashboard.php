<?php
   include('./Partials/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/dashboard.css">
   <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
   <title>Document</title>
</head>

<body>
   <?php include_once('./Partials/sidebar.php'); ?>

   <div class="container">
      <div class="row">
         <div class="col-md-3">
            <div class="card-counter primary">
               <i class="fa fa-code-fork"></i>
               <span class="count-numbers">12</span>
               <span class="count-name">Flowz</span>
            </div>
         </div>

         <div class="col-md-3">
            <div class="card-counter danger">
               <i class="fa fa-ticket"></i>
               <?php
               $query = mysqli_query($con, "SELECT * FROM table_services");
               $cnt = mysqli_num_rows($query);
            ?>
               <span class="count-numbers"><?php echo $cnt;?></span>
               <span class="count-name">Services</span>
            </div>
         </div>

         <div class="col-md-3">
            <div class="card-counter success">
               <i class="fa fa-database"></i>
               <?php
                $query = mysqli_query($con, "SELECT * FROM registration");
                $cnt = mysqli_num_rows($query);
            ?>
               <span class="count-numbers"><?php echo $cnt;?></span>
               <span class="count-name">Customers</span>
            </div>
         </div>

         <div class="col-md-3">
            <div class="card-counter info">
               <i class="fa fa-users"></i>
               <?php
                $query = mysqli_query($con, "SELECT * FROM appointments");
                $cnt = mysqli_num_rows($query);
            ?>
               <span class="count-numbers"><?php echo $cnt; ?></span>
               <span class="count-name">Appointments</span>
            </div>
            
         </div>
         
      </div>
   </div>
</body>

</html>