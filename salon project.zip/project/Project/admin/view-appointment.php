<?php
include('./Partials/dbconnection.php');

$vid = $_GET['viewid'];
if (isset($_POST['btn1'])) {
   $query = mysqli_query($con, "UPDATE appointments SET status='Accepted' WHERE id = '$vid'");
   if ($query) {
      echo "<script>alert('Service has been added.');</script>";
      echo "<script>window.location.href = 'services.php'</script>";
   } else {
      echo "<script>alert('Something Went Wrong. Please try again.');</script>";
   }
}

if (isset($_POST['btn'])) {
   $vid = $_GET['viewid'];
   $query = mysqli_query($con, "INSERT INTO appointments(status) VALUES('Rejected') WHERE id = '$vid'");
   if ($query) {
      echo "<script>alert('Service has been added.');</script>";
      echo "<script>window.location.href = 'services.php'</script>";
   } else {
      echo "<script>alert('Something Went Wrong. Please try again.');</script>";
   }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/view-appointment.css">
   <title>Document</title>
</head>

<body>
   <?php include_once('./Partials/sidebar.php'); ?>
   <div class="main" style="margin-top: 40px;">
      <h3 style="font-weight: bold;">Appointment</h3>
      <div class="table">
         <table width="100%">
            <!-- <tbody> -->
            <?php
            $vid = $_GET['viewid'];
            $ret = mysqli_query($con, "SELECT * FROM appointments WHERE id = '$vid'");
            $cnt = 1;

            while ($row = mysqli_fetch_array($ret)) {

            ?>
               <tr>
                  <th>First Name </th>
                  <td><?php echo $row['first_name']; ?></td>
               </tr>
               <tr>
                  <th>Last Name</th>
                  <td><?php echo $row['last_name']; ?></td>
               </tr>
               <tr>
                  <th>Email</th>
                  <td><?php echo $row['email']; ?></td>
               </tr>
               <tr>
                  <th>Phone</th>
                  <td><?php echo $row['phone']; ?></td>
               </tr>
               <tr>
                  <th>Service</th>
                  <td><?php echo $row['service']; ?></td>
               </tr>
               <tr>
                  <th>Date</th>
                  <td><?php echo $row['date']; ?></td>
               </tr>
               <tr>
                  <th>Time</th>
                  <td><?php echo $row['time']; ?></td>
               </tr>
               <tr>
                  <th>Appointment Number</th>
                  <td><?php echo $row['aptNo']; ?></td>
               </tr>
               <tr>
                  <th>Status</th>
                  <td id="confirm"></td>
               </tr>
            <?php $cnt = $cnt + 1;
            } ?>
            <!-- </tbody> -->
         </table>
      </div>
      <div onclick="btn1();" class="buttons">
         <div class="btn1">
            <button type="submit" name="btn1">Accept Appointment</button>
         </div>
         <div onclick="btn();" class="btn">
            <button type="submit" name="btn">Reject Appointment</button>
         </div>
      </div>
      <div style="padding: 20px;" class="buttons">
         <button  style="padding: 15px; background-color: green;" type="button" onclick="window.location.href = './appointments.php'">Go back</button>
      </div>
   </div>
</body>

<script>
   const btn1 = () => {
      document.getElementById('confirm').innerHTML = 'Accepted';
   }

   const btn = () => {
      document.getElementById('confirm').innerHTML = 'Rejected';
   }
</script>

</html>