<?php
    include('./Partials/dbconnection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us Section</title>
    <link rel="stylesheet" href="./css/aboutus.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
   <?php include_once('./Partials/NavBar.php') ?>
    <div class="section">
        <div class="container">
            <div class="content-section">
                <div class="title">
                <?php
				    $ret = mysqli_query($con, "SELECT * FROM table_pages");
				    $cnt = 1;

				    while ($row = mysqli_fetch_array($ret)) {

				?>
                    <h1><?php echo $row['page_title']; ?></h1>
                </div>
                <div class="content">
                    <h3><?php echo $row['page_title']; ?></h3>
                    <p><?php echo $row['page_description']; ?></p>
                </div>
                <?php } ?>

            </div>
            <div class="image-section">
                <img src="./images/Aboutus1.jpg">
            </div>
        </div>
    </div>
   <?php include_once('./Partials/Footer.php') ?>
</body>
</html>