<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link rel="stylesheet" href="./css/home (1).css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class="body_area">
        <section>
            <div class="nav-area">
                <ul>
                    <li><a href="./services">Services</a></li>
                    <li><a href="./aboutus">About Us</a></li>
                    <li><a href="/contacts">Contact Us</a></li>
                    <!-- <li><a href="location">Location</a></li> -->
                </ul>
                <div class="buttons">
                    <ul>
                        <li><a href="./login.php">Login</a></li>
                        <li><a href="./registration.php">Register</a></li>
                    </ul>
                </div>
            </div>

            </nav>
        </section>
        <section>
            <div class="bodyarea"></div>
            <div class="name">
                <h1 class="font-effect-outline">Elegance Salon</h1>
            </div>
            <div class="book">
                <a href="./login.php">BOOK NOW</a>
            </div>
    </div>
    </section>
</div>

</body>

</html>